package com.tiendat.omnichat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmnichatApplicationTests {

	@Test
	void contextLoads() {
	}

}
