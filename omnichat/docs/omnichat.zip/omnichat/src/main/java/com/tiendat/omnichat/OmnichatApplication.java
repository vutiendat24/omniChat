package com.tiendat.omnichat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmnichatApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmnichatApplication.class, args);
	}

}
